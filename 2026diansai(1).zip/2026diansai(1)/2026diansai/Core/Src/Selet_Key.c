/**
 ******************************************************************************
 * @file    Selet_Key.c
 * @brief   4 按键扫描 — 按下时切换 my_task（边沿触发 + 消抖）
 *          PA4 -> task1
 *          PA5 -> task2
 *          PA6 -> task3
 *          PA7 -> task3
 *
 *          所有按键已配置为 GPIO_MODE_INPUT + GPIO_PULLUP，
 *          按下时读到低电平 (GPIO_PIN_RESET)。
 *          采样周期 50ms，自带去抖效果。
 ******************************************************************************
 */

#include "Selet_Key.h"
#include "main.h"
#include "task_motor.h"

void Selet_Key_Scan(void)
{
    static uint8_t last_state = 0xFF;  /* 上一次的 4 位按键状态，1=释放, 0=按下 */
    uint8_t cur = 0;

    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_4) == GPIO_PIN_SET) cur |= 0x01;
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_5) == GPIO_PIN_SET) cur |= 0x02;
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_6) == GPIO_PIN_SET) cur |= 0x04;
    if (HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_7) == GPIO_PIN_SET) cur |= 0x08;

    /* 边沿检测：上次为高(释放) 且 本次为低(按下) = 下降沿 */
    uint8_t pressed = last_state & ~cur;

    if (pressed & 0x01)      my_task = task1;
    else if (pressed & 0x02) my_task = task2;
    else if (pressed & 0x04) my_task = task3;
    else if (pressed & 0x08) my_task = task3;

    last_state = cur;
}

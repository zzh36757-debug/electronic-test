#include "limit.h"

float abs_f(float x)
{
    return (x >= 0.0f) ? x : -x;
}

float move_toward_f(float cur, float target, float step)
{
    if (cur < target - step) return cur + step;
    if (cur > target + step) return cur - step;
    return target;
}


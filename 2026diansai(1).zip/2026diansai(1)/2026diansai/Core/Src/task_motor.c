/**
 ******************************************************************************
 * @file    task_motor.c
 * @brief   水管钢珠水平平衡 — KP×位置偏差 − KD×速度
 *          摄像头已做滤波，STM32 直接使用 X 和 V
 *          支持串口在线调参：USART1 收 "target,kp,kd" 格式命令
 *          支持任务切换：USART1 收 "task:N" 切换任务
 ******************************************************************************
 */

#include "task_motor.h"
#include "cmsis_os.h"
#include "main.h"
#include "Emm_V5.h"
#include "camera_uart.h"
#include "usart.h"
#include <stdio.h>
#include <stdlib.h>
#include "limit.h"
#include "Selet_Key.h"

/*外部变量声明*/
extern UART_HandleTypeDef huart1;

/* 任务选择枚举定义见 task_motor.h */
volatile task_num my_task = task2;

/* task1 */
#define T1_POS_TARGET      223
#define T1_NEG_TARGET      80

#define T1_REF_STEP_POS    4.0f
#define T1_REF_STEP_NEG    3.5f

#define T1_SWITCH_ERR      8
#define T1_DONE_ERR        5

#define T1_SWITCH_VEL      5.0f
#define T1_DONE_VEL        5.0f

#define T1_SWITCH_FRAMES   2
#define T1_DONE_FRAMES     3

#define T1_TIMEOUT_MS      5000U
#define T1_REPORT_MS       20U

#define T1_NEG_BIAS        0       /* 负向补偿，回 -5 时额外多给一点左推力 */

static int32_t  target_x    = T1_POS_TARGET;

static float    kp_pos      = 1.5f;
static float    kd_pos      = 50.0f;

static float    kp_neg      =2.0;
static float    kd_neg      = 50.0f;

static float    ki          = 0.0f;
static float    kf          = 0.0f;

		/*task2*/
static int32_t  target_x_2  = 142;       /* 目标 X 坐标（小球平衡中心点） */
static float    kp2         = 2.0f;      /* 位置比例：偏差越大，往回拉的力越大 */
static float    ki2         = 0.02f;      /* 速度阻尼：速度越快，刹车越狠 */
static float    kd2         = 36.0f;      /* 速度阻尼：速度越快，刹车越狠 */
static float    kf2         = 0.0f;

		/*task3*/
static int32_t  target_x_3  = 155;       /* 目标 X 坐标（小球平衡中心点） */
static float    kp3         = 1.6f;      /* 位置比例：偏差越大，往回拉的力越大 */
static float    ki3         = 0.45f; 
static float    kd3         = 50.0f;      /* 速度阻尼：速度越快，刹车越狠 */
static float    kf3         = 0.0f;

//static int32_t  target_x_2  = 142;       /* 目标 X 坐标（小球平衡中心点） */
//static float    kp2         = 2.0f;      /* 位置比例：偏差越大，往回拉的力越大 */
//static float    ki2         = 0.02f;      /* 速度阻尼：速度越快，刹车越狠 */
//static float    kd2         = 40.0f;      /* 速度阻尼：速度越快，刹车越狠 */
//static float    kf2         = 0.0f;

/*==================================================================
 *  固定参数
 *==================================================================*/
#define DEAD_ZONE        1               /* 死区（像素）：偏差在此范围内不动作 */
#define DEAD_ZONE2       0               /* 死区（像素）：偏差在此范围内不动作 */
#define DEAD_ZONE3       0               /* 死区（像素）：偏差在此范围内不动作 */
#define MAX_DELTA       80              /* 单次位置增量上限，防止突变 */
#define POS_VEL         400             /* 电机运动速度（RPM） */
#define POS_ACC         240             /* 电机加速度 */
#define	SUM_MAX			50									/*误差累积项限幅*/


/*==================================================================
 *  Task_Motor_Run — 电机控制任务
 *==================================================================*/
void Task_Motor_Run(void *argument)
{
    /* ---- 上电延时，等电机初始化 ---- */
    osDelay(1000);

    /* ---- 电机回零（单圈就近回零） ---- */
    Emm_V5_Origin_Trigger_Return(1, 0, false);


    /* ---- 控制变量 ---- */
    int32_t camera_x   = 0;      /* 摄像头：小球 X 坐标（像素） */
    int32_t camera_v   = 0;      /* 摄像头：小球速度（带符号，正=往右，负=往左） */
		float camera_a   = 0;
		float error      = 0;     					 /* 位置偏差 = 目标 − 实际 */
		float last_error      = 0;			/* 上一次位置偏差 =  位置偏差*/
		static float sum_err = 0;		 /*误差累积*/
    int32_t motor_out  = 0;      /* 控制输出（脉冲），直接作为电机位置 */
	
		/*任务一变量*/
		typedef enum {
    T1_ENTER = 0,
    T1_TO_POS,
    T1_TO_NEG,
    T1_DONE,
    T1_TIMEOUT
} task1_state_t;
	
		 task1_state_t t1_state = T1_ENTER;
    float ref_x = 0.0f;
    float v_f = 0.0f;
    uint8_t stable_cnt = 0;
    uint32_t t1_start_ms = 0;
    uint32_t t1_last_report_ms = 0;

		/*通过摄像头数据，计算需要的参数*/
		float calculate_a;
		float last_calculate_a;
	
    for(;;)
    {
        /* ---- 按键扫描（每 50ms 一次）---- */
        {
            static uint8_t key_tick = 0;
            if (++key_tick >= 25)  /* 25 × 2ms = 50ms */
            {
                key_tick = 0;
                Selet_Key_Scan();
            }
        }

        /*任务一，小球+5到-5
					任务2，小球稳定在中间位置
					任务3，小球稳定在任意位置
			*/
			
			switch(my_task)
			{
        case task0:
        {
			    Emm_V5_Origin_Trigger_Return(1, 0, false);
        }
        break;

       case task1:
        {
					
					uint32_t now_ms = HAL_GetTick();
            if (Camera_NewDataAvailable())
            {
                float kp_run = kp_pos;
                float kd_run = kd_pos;
                float ref_step_run = T1_REF_STEP_POS;
                

                camera_x = Camera_GetX();
                camera_v = -Camera_GetV();
                camera_a = -Camera_GetA();

                v_f = 0.7f * v_f + 0.3f * (float)camera_v;

                if (t1_state == T1_ENTER)
                {
                    target_x = T1_POS_TARGET;
                    ref_x = (float)camera_x;
                    stable_cnt = 0;
                    sum_err = 0.0f;
                    t1_start_ms = now_ms;
                    t1_last_report_ms = now_ms;
                    t1_state = T1_TO_POS;
                }

                if ((now_ms - t1_start_ms) > T1_TIMEOUT_MS)
                {
                    t1_state = T1_TIMEOUT;
                }

                if (t1_state == T1_TO_POS)
                {
                    target_x = T1_POS_TARGET;
                    kp_run = kp_pos;
                    kd_run = kd_pos;
                    ref_step_run = T1_REF_STEP_POS;
                }
                else
                {
                    target_x = T1_NEG_TARGET;
                    kp_run = kp_neg;
                    kd_run = kd_neg;
                    ref_step_run = T1_REF_STEP_NEG;
                }

                if (t1_state != T1_DONE)
                {
                    ref_x = move_toward_f(ref_x, (float)target_x, ref_step_run);
                }
                else
                {
                    ref_x = (float)target_x;
                }

                error = ref_x - (float)camera_x;
                motor_out = (int32_t)(kp_run * error - kd_run * v_f);

                /* 回 -5 时，如果还离得远且速度很小，补一点固定左推力 */
                if ((t1_state == T1_TO_NEG || t1_state == T1_TIMEOUT) &&
                    (camera_x > (T1_NEG_TARGET + 10)) &&
                    (abs_f(v_f) < 2.0f))
                {
                    motor_out -= T1_NEG_BIAS;
                }

                if (motor_out > MAX_DELTA) motor_out = MAX_DELTA;
                else if (motor_out < -MAX_DELTA) motor_out = -MAX_DELTA;

                {
                    uint8_t dir = (motor_out >= 0) ? 1 : 0;
                    uint32_t clk = (uint32_t)((motor_out >= 0) ? motor_out : -motor_out);
                    Emm_V5_Pos_Control(1, dir, POS_VEL, POS_ACC, clk, 1, false);

                    if (t1_state == T1_TO_POS)
                    {
                        if ((abs(camera_x - T1_POS_TARGET) <= T1_SWITCH_ERR) &&
                            (abs_f(v_f) <= T1_SWITCH_VEL))
                        {
                            if (++stable_cnt >= T1_SWITCH_FRAMES)
                            {
                                stable_cnt = 0;
                                t1_state = T1_TO_NEG;
                            }
                        }
                        else
                        {
                            stable_cnt = 0;
                        }
                    }
                    else if (t1_state == T1_TO_NEG)
                    {
                        if ((abs(camera_x - T1_NEG_TARGET) <= T1_DONE_ERR) &&
                            (abs_f(v_f) <= T1_DONE_VEL))
                        {
                            if (++stable_cnt >= T1_DONE_FRAMES)
                            {
                                t1_state = T1_DONE;
                            }
                        }
                        else
                        {
                            stable_cnt = 0;
                        }
                    }

                    if ((now_ms - t1_last_report_ms) >= T1_REPORT_MS)
                    {
                        char tx_buf[96];
                        int tx_len = sprintf(tx_buf,
                                             "%d,%ld,%.1f,%ld,%.1f,%ld,%u,%lu\r\n",
                                             (int)t1_state,
                                             (long)target_x,
                                             (double)ref_x,
                                             (long)camera_x,
                                             (double)v_f,
                                             (long)motor_out,
                                             (unsigned int)stable_cnt,
                                             (unsigned long)(now_ms - t1_start_ms));
                        HAL_UART_Transmit(&huart1, (uint8_t *)tx_buf, tx_len, 100);
                        t1_last_report_ms = now_ms;
                    }
                }
            }
        }
        break;

        case task2:
        {
			uint32_t now_ms = HAL_GetTick();
			           /* ---- 等摄像头来新数据 ---- */
            if (Camera_NewDataAvailable())
            {
                camera_x = Camera_GetX();
                camera_v = -Camera_GetV();
								camera_a = -Camera_GetA();

                error = target_x_2 - camera_x;
								sum_err += error;
                /* ---- 死区 ---- */
                if (error > -DEAD_ZONE2 && error < DEAD_ZONE2)
                {
                    continue;
                }
							if(sum_err > SUM_MAX) sum_err = SUM_MAX;
							if(sum_err < -SUM_MAX) sum_err = -SUM_MAX;
				
                motor_out = (int32_t)(kp2 * error  + ki2 * sum_err  - kd2 * camera_v -kf2 * camera_a);

                /* ---- 位置限幅 ---- */
                if      (motor_out >  MAX_DELTA) motor_out =  MAX_DELTA;
                else if (motor_out < -MAX_DELTA) motor_out = -MAX_DELTA;

                /* ---- 直接作为位置发出去，不累加 ---- */
                uint8_t  dir = (motor_out >= 0) ? 1 : 0;
                uint32_t clk = (uint32_t)(motor_out >= 0 ? motor_out : -motor_out);
                Emm_V5_Pos_Control(1, dir, POS_VEL, POS_ACC, clk, 1, false);
								
								last_error = error;
								
                    if ((now_ms - t1_last_report_ms) >= T1_REPORT_MS)
                    {
                        char tx_buf[96];
                        int tx_len = sprintf(tx_buf,
                                             "%ld,%ld,%ld,%u\r\n",
                                             (long)target_x,
                                             (long)camera_x,
                                             (long)motor_out);
                        HAL_UART_Transmit(&huart1, (uint8_t *)tx_buf, tx_len, 100);
                        t1_last_report_ms = now_ms;
                    }
            }
           
        }
        break;

        case task3:
        {
			uint32_t now_ms = HAL_GetTick();
			           /* ---- 等摄像头来新数据 ---- */
            if (Camera_NewDataAvailable())
            {
                camera_x = Camera_GetX();
                camera_v = -Camera_GetV();
								camera_a = -Camera_GetA();

                error = target_x_3 - camera_x;
								sum_err += error;
                /* ---- 死区 ---- */
                if (error > -DEAD_ZONE3 && error < DEAD_ZONE3)
                {
                    continue;
                }
							if(sum_err > SUM_MAX) sum_err = SUM_MAX;
							if(sum_err < -SUM_MAX) sum_err = -SUM_MAX;
				
                motor_out = (int32_t)(kp3 * error  + ki3 * sum_err  - kd3 * camera_v -kf3 * camera_a);

                /* ---- 位置限幅 ---- */
                if      (motor_out >  MAX_DELTA) motor_out =  MAX_DELTA;
                else if (motor_out < -MAX_DELTA) motor_out = -MAX_DELTA;

                /* ---- 直接作为位置发出去，不累加 ---- */
                uint8_t  dir = (motor_out >= 0) ? 1 : 0;
                uint32_t clk = (uint32_t)(motor_out >= 0 ? motor_out : -motor_out);
                Emm_V5_Pos_Control(1, dir, POS_VEL, POS_ACC, clk, 1, false);
								
								last_error = error;
								
                    if ((now_ms - t1_last_report_ms) >= T1_REPORT_MS)
                    {
                        char tx_buf[96];
                        int tx_len = sprintf(tx_buf,
                                             "%ld,%ld,%ld,%u\r\n",
                                             (long)target_x,
                                             (long)camera_x,
                                             (long)motor_out);
                        HAL_UART_Transmit(&huart1, (uint8_t *)tx_buf, tx_len, 100);
                        t1_last_report_ms = now_ms;
                    }
            }
        }
        break;
			}

		 osDelay(2);
    }
}

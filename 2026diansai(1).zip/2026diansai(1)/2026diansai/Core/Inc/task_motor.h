#ifndef __TASK_MOTOR_H
#define __TASK_MOTOR_H

#ifdef __cplusplus
extern "C" {
#endif

/* 任务选择枚举 */
typedef enum {
    task0,
    task1,
    task2,
    task3,
    task4,
    task5
} task_num;

/* 全局任务变量，在 task_motor.c 中定义 */
extern volatile task_num my_task;

void Task_Motor_Run(void *argument);

#ifdef __cplusplus
}
#endif

#endif /* __TASK_MOTOR_H */

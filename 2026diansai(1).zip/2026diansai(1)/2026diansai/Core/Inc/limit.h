#ifndef __LIMIT_H
#define __LIMIT_H

#include "stm32f4xx_hal.h"

float abs_f(float x);
float move_toward_f(float cur, float target, float step);

#endif

#ifndef __SELET_KEY_H
#define __SELET_KEY_H

#ifdef __cplusplus
extern "C" {
#endif

void Selet_Key_Scan(void);

#ifdef __cplusplus
}
#endif

#endif /* __SELET_KEY_H */

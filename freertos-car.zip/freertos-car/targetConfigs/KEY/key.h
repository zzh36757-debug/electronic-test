#ifndef KEY_H
#define KEY_H

#include "ti_msp_dl_config.h"
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 按键宏 */
#define KEY1_PORT   GPIO_Key_PORT
#define KEY1_PIN    GPIO_Key_Key1_PIN
#define KEY2_PORT   GPIO_Key_PORT
#define KEY2_PIN    GPIO_Key_Key2_PIN
#define KEY3_PORT   GPIO_Key_PORT
#define KEY3_PIN    GPIO_Key_Key3_PIN
#define KEY4_PORT   GPIO_Key_PORT
#define KEY4_PIN    GPIO_Key_Key4_PIN

void Key_Init(void);   /* 初始化按键上拉 */

/* 读键：返回 1=按下(LOW), 0=松开(HIGH) */
uint8_t Key1_Read(void);
uint8_t Key2_Read(void);
uint8_t Key3_Read(void);
uint8_t Key4_Read(void);

#ifdef __cplusplus
}
#endif

#endif /* KEY_H */

#include "key.h"
#include "FreeRTOS.h"
#include "task.h"

#define KEY_DEBOUNCE_MS  10   /* 消抖延时 10ms */

/* 初始化按键：开启内部上拉（SysConfig 没开） */
void Key_Init(void)
{
    DL_GPIO_initDigitalInputFeatures(GPIO_Key_Key1_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initDigitalInputFeatures(GPIO_Key_Key2_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initDigitalInputFeatures(GPIO_Key_Key3_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
    DL_GPIO_initDigitalInputFeatures(GPIO_Key_Key4_IOMUX,
        DL_GPIO_INVERSION_DISABLE, DL_GPIO_RESISTOR_PULL_UP,
        DL_GPIO_HYSTERESIS_DISABLE, DL_GPIO_WAKEUP_DISABLE);
}

/* 读取按键1 (PB8)：按下返回1，松开返回0 */
uint8_t Key1_Read(void)
{
    if (DL_GPIO_readPins(KEY1_PORT, KEY1_PIN) == 0)
    {
        vTaskDelay(pdMS_TO_TICKS(KEY_DEBOUNCE_MS));
        if (DL_GPIO_readPins(KEY1_PORT, KEY1_PIN) == 0)
            return 1;
    }
    return 0;
}

/* 读取按键2 (PB9)：按下返回1，松开返回0 */
uint8_t Key2_Read(void)
{
    if (DL_GPIO_readPins(KEY2_PORT, KEY2_PIN) == 0)
    {
        vTaskDelay(pdMS_TO_TICKS(KEY_DEBOUNCE_MS));
        if (DL_GPIO_readPins(KEY2_PORT, KEY2_PIN) == 0)
            return 1;
    }
    return 0;
}

/* 读取按键3 (PB10)：按下返回1，松开返回0 */
uint8_t Key3_Read(void)
{
    if (DL_GPIO_readPins(KEY3_PORT, KEY3_PIN) == 0)
    {
        vTaskDelay(pdMS_TO_TICKS(KEY_DEBOUNCE_MS));
        if (DL_GPIO_readPins(KEY3_PORT, KEY3_PIN) == 0)
            return 1;
    }
    return 0;
}

/* 读取按键4 (PB11)：按下返回1，松开返回0 */
uint8_t Key4_Read(void)
{
    if (DL_GPIO_readPins(KEY4_PORT, KEY4_PIN) == 0)
    {
        vTaskDelay(pdMS_TO_TICKS(KEY_DEBOUNCE_MS));
        if (DL_GPIO_readPins(KEY4_PORT, KEY4_PIN) == 0)
            return 1;
    }
    return 0;
}

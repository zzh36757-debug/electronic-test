#ifndef _LED_H
#define _LED_H
#include "ti_msp_dl_config.h"
    

void LED1_ON(void);
void LED1_OFF(void);
void LED1_Toggle(void);
void LED2_ON(void);
void LED2_OFF(void);
void LED2_Toggle(void);

#endif 


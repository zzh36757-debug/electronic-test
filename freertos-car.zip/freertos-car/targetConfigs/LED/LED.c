#include "LED.h"


void LED1_ON(void)
{
	
	DL_GPIO_setPins(LED_PORT,LED_led_PIN);
}

void LED1_OFF(void)
{
	DL_GPIO_clearPins(LED_PORT,LED_led_PIN);
}

void LED1_Toggle(void)
{
	DL_GPIO_togglePins(LED_PORT,LED_led_PIN);
}

void LED2_ON(void)
{
	DL_GPIO_setPins(LED_PORT,LED_led2_PIN);
}

void LED2_OFF(void)
{
	DL_GPIO_clearPins(LED_PORT,LED_led2_PIN );
}

void LED2_Toggle(void)
{
	DL_GPIO_togglePins(LED_PORT,LED_led2_PIN);
}
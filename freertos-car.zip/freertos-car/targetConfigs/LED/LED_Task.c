#include "FreeRTOS.h"
#include "LED_Task.h"
#include "task.h"
#include "LED.h"

void LedTask(void *pvParameters)
{
    LED1_OFF();
    LED2_OFF();
    for (;;) {

        vTaskDelay(pdMS_TO_TICKS(500));
    }
}
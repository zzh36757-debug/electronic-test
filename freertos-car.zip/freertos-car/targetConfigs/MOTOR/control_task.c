#include "control_task.h"
#include "FreeRTOS.h"
#include "task.h"
#include "ti_msp_dl_config.h"  // 根据实际硬件驱动调整


#include <stdio.h>
#include "motor.h"
#include "../ENCODER/encoder.h"
#include "../ENCODER/encoder_task.h"
#include "../XUNJI/xunji_task.h"
//#include "../JY61P/Jy61p_task.h"
#include "../MSPM0GYRO/Gyro_task.h"

volatile int32_t encoderA_cnt, encoderB_cnt;
volatile int32_t PWM_outA, PWM_outB;

/* 任务主函数 */
void ControlTask(void *pvParameters)           //从机显示和按键函数
{
    int32_t PWMA = 0, PWMB = 0;
    int M_Straight_Target_Vel = 80;
    int M_Error_Target_Vel = 75;
    int M_Straight_error = 5;
    int M_Turn_Target_Vel = 50;
    int delta_v = 18;
    int pulse_accum = 0;
    int drive_state = Straight_Mode;
    int lb;

    float angle_out = 0.0f;  /* 角度环输出 */



    /* 任务主循环 */
    for (;;) {
              encoderA_cnt = countA;
              encoderB_cnt = countB;

              
                    switch(drive_state)
            {
                case Straight_Mode:
            if(( ((CH1&&CH2&&CH3&&CH6&&CH7&&CH8) && !(CH4&&CH5) ))||!((CH1||CH2||CH3||CH4)))
            {
                PWMA = Velocity_A(&A_Motor_PID,M_Straight_Target_Vel,encoderA_cnt);//PID控制
                PWMB = Velocity_B(&B_Motor_PID,M_Straight_Target_Vel,encoderB_cnt);//PID控制
            }
             else if(!(CH6 && CH7)&&(CH1&&CH2&&CH3&&CH4))
                {
                PWMA = Velocity_A(&A_Motor_PID,M_Error_Target_Vel-M_Straight_error,encoderA_cnt);//PID控制
                PWMB = Velocity_B(&B_Motor_PID,M_Error_Target_Vel+M_Straight_error,encoderB_cnt);//PID控制
                }
                else if((!(CH2&&CH3))&&(CH1&&CH5&&CH6&&CH7&&CH8))
                {
                PWMA = Velocity_A(&A_Motor_PID,M_Error_Target_Vel+M_Straight_error,encoderA_cnt);//PID控制
                PWMB = Velocity_B(&B_Motor_PID,M_Error_Target_Vel-M_Straight_error,encoderB_cnt);//PID控制
                lb=0;
                }
                else if(CH1&&CH2&&CH3&&CH4&&CH5&&CH6&&CH7&&CH8)
                {
                    lb++;
                    if(lb>=5)
                    {
                    drive_state = Turn_Mode;
                    lb=0;
                    }
                }

            Turn_PID_Clean(&Turn_A_Motor_PID,&Turn_B_Motor_PID);
                                            //占空比取值范围:0~7999;
                PWMA=limit_PWM(PWMA,-7999,7999);
                PWMB=limit_PWM(PWMB,-7999,7999);
                 Set_PWM(PWMA,PWMB);//PWM控制电机
            break;
            case Turn_Mode:
            PWMA = Turn_A(&Turn_A_Motor_PID,M_Turn_Target_Vel+delta_v,encoderA_cnt);//PID控制
            PWMB = Turn_B(&Turn_B_Motor_PID,M_Turn_Target_Vel-delta_v,encoderB_cnt);//PID控制
            pulse_accum +=encoderA_cnt;
            if(pulse_accum >= Target_pulse)
            {
                pulse_accum = 0;
                drive_state = Straight_Mode;
            }
                                            //占空比取值范围:0~7999;
                PWMA=limit_PWM(PWMA,-7999,7999);
                PWMB=limit_PWM(PWMB,-7999,7999);
                 Set_PWM(PWMA,PWMB);//PWM控制电机
        break;
        }
        

    
        /*
        angle_out = Angle_Control(&Angle_Motor_PID, stcAngle.Yaw);
        PWMA = (int32_t)(-angle_out);   
        PWMB = (int32_t)angle_out;   
        PWMA = limit_PWM(PWMA, -7000, 7000);
        PWMB = limit_PWM(PWMB, -7000, 7000);
        Set_PWM(PWMA, PWMB);
        PWM_outA = PWMA;
        PWM_outB = PWMB;
        */
        
        vTaskDelay(pdMS_TO_TICKS(10));


    }

    /* 理论上不会执行到这里 */
    vTaskDelete(NULL);
}
        //int pulse = Get_Encoder_countA;
        //if (pulse < 0) pulse = -pulse;
        /*
        encoderA_cnt = countA;
        encoderB_cnt = countB;
        PWMA = Velocity_A(&A_Motor_PID,M_Straight_Target_Vel,encoderA_cnt);//PID控制
        PWMB = Velocity_B(&B_Motor_PID,M_Straight_Target_Vel,encoderB_cnt);//PID控制
        PWMA=limit_PWM(PWMA,-7999,7999);
        PWMB=limit_PWM(PWMB,-7999,7999);
        PWM_outA = PWMA;
        PWM_outB = PWMB;
        Set_PWM(PWMA,PWMB);//PWM控制电机
        */

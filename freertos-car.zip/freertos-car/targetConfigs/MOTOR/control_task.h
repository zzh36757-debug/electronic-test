#ifndef CONTROL_TASK_H
#define CONTROL_TASK_H

#include "FreeRTOS.h"
#include "task.h"
#include <stdint.h>

#define Straight_Mode 1
#define Turn_Mode 2 
#define Target_pulse 47300

void ControlTask(void *pvParameters);

/* 编码器捕获值（每周期更新） */
extern volatile int32_t encoderA_cnt;
extern volatile int32_t encoderB_cnt;
extern volatile int32_t PWM_outA;
extern volatile int32_t PWM_outB;
#endif

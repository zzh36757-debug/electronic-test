#include "FreeRTOS.h"
#include "motor.h"
#include "task.h"
#include <stdlib.h>
#define ABS(x) abs(x)

VelocityPI A_Motor_PID = {
	.kp=96.0f,
	.ki=0.8f,
	.output = 0,
	.error = 0,
	.last_error=0,
	.output_min=-7000,
	.output_max=7000
};
VelocityPI B_Motor_PID = {
	.kp=96.0f,
	.ki=0.8f,
	.output = 0,
	.error = 0,
	.last_error=0,
	.output_min=-7000,
	.output_max=7000
};
TurnPI Turn_A_Motor_PID = {
	.kp=96.0f,
	.ki=0.8f,
	.output = 0,
	.error = 0,
	.last_error=0,
	.output_min=-7000,
	.output_max=7000
};
TurnPI Turn_B_Motor_PID = {
	.kp=96.0f,
	.ki=0.8f,
	.output = 0,
	.error = 0,
	.last_error=0,
	.output_min=-7000,
	.output_max=7000
};

AnglePI Angle_Motor_PID = {
	.kp = 15.0f,
	.ki = 0.1f,
	.target = 90.0f,          /* 目标角度 */
	.output = 0,
	.error = 0.0f,
	.integral = 0.0f,
	.integral_max = 3000.0f,  /* 积分限幅 */
	.output_min = -800,
	.output_max =  800
};


int limit_PWM(int value,int low,int high)
{
	if(value>high) return high;
	else if(value<low) return low;
	else return value;
}

void Set_PWM(int pwmL,int pwmR)
{
	 if(pwmL>=0)
    {
		DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(8000),GPIO_PWM_0_C0_IDX);
		DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(8000-pwmL),GPIO_PWM_0_C1_IDX);
       
    }
    else
    {
		DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(8000+pwmL),GPIO_PWM_0_C0_IDX);
		DL_Timer_setCaptureCompareValue(PWM_0_INST,ABS(8000),GPIO_PWM_0_C1_IDX);
       
    }
	
	 if(pwmR>=0)
    {
		DL_Timer_setCaptureCompareValue(PWM_1_INST,ABS(8000),GPIO_PWM_1_C0_IDX);
		DL_Timer_setCaptureCompareValue(PWM_1_INST,ABS(8000-pwmR),GPIO_PWM_1_C1_IDX);
       
    }
    else
    {
		DL_Timer_setCaptureCompareValue(PWM_1_INST,ABS(8000+pwmR),GPIO_PWM_1_C0_IDX);
		DL_Timer_setCaptureCompareValue(PWM_1_INST,ABS(8000),GPIO_PWM_1_C1_IDX);
       
    }
	
	
}



int Velocity_A(volatile VelocityPI *pid,int TargetVelocity, int CurrentVelocity)
{  

		pid->error =  TargetVelocity-CurrentVelocity;
		pid->output += pid->kp*(pid->error-pid->last_error)+pid->ki*pid->error;
		pid->last_error = pid->error;
		if(pid->output>7000) pid->output=7000;
	    else if(pid->output<-7000) pid->output=-7000;
		return pid->output; //

}
int Velocity_B(volatile VelocityPI *pid,int TargetVelocity, int CurrentVelocity)
{  
		pid->error =  TargetVelocity-CurrentVelocity;
		pid->output += pid->kp*(pid->error-pid->last_error)+pid->ki*pid->error;
		pid->last_error = pid->error;
		if(pid->output>7000) pid->output=7000;
	    else if(pid->output<-7000) pid->output=-7000;
		return pid->output; //

}
int Turn_A(volatile TurnPI*pid,int TargetVelocity, int CurrentVelocity)
{  

		pid->error =  TargetVelocity-CurrentVelocity;
		pid->output += pid->kp*(pid->error-pid->last_error)+pid->ki*pid->error;
		pid->last_error = pid->error;
		if(pid->output>7000) pid->output=7000;
	    else if(pid->output<-7000) pid->output=-7000;
		return pid->output; //

}
int Turn_B(volatile TurnPI *pid,int TargetVelocity, int CurrentVelocity)
{  
		pid->error =  TargetVelocity-CurrentVelocity;
		pid->output += pid->kp*(pid->error-pid->last_error)+pid->ki*pid->error;
		pid->last_error = pid->error;
		if(pid->output>7000) pid->output=7000;
	    else if(pid->output<-7000) pid->output=-7000;
		return pid->output; //

}
/* 角度环 PI 控制器（位置式，处理 ±180° 环绕） */
float Angle_Control(volatile AnglePI *pid, float CurrentAngle)
{
    /* 计算误差 */
    pid->error = pid->target - CurrentAngle;

    /* ±180° 环绕处理 */
    if (pid->error > 180.0f)  pid->error -= 360.0f;
    if (pid->error < -180.0f) pid->error += 360.0f;

    /* 死区：3° 以内不调，同时清积分防积累 */
    if (pid->error > -3.0f && pid->error < 3.0f)
    {
        pid->error    = 0.0f;
        pid->integral = 0.0f;
    }

    /* 积分累加 */
    pid->integral += pid->error;
    if (pid->integral >  pid->integral_max) pid->integral =  pid->integral_max;
    if (pid->integral < -pid->integral_max) pid->integral = -pid->integral_max;

    /* 位置式 PI：output = Kp*e + Ki*∫e */
    pid->output = pid->kp * pid->error + pid->ki * pid->integral;

    /* 限幅 */
    if(pid->output>7000) pid->output=7000;
    if (pid->output < pid->output_min) pid->output = pid->output_min;

    return pid->output;
}

void Turn_PID_Clean(volatile TurnPI *pidA,volatile TurnPI *pidB)
{
	pidA->error=0;
	pidA->last_error = 0;
	pidA->output = 0;
	pidB->error=0;
	pidB->last_error = 0;
	pidB->output = 0;
}

/*
int Velocity_A(int TargetVelocity, int CurrentVelocity)
{  
    int Bias; 
		static int ControlVelocityA, Last_biasA; 
		
		Bias=TargetVelocity-CurrentVelocity; 
		
		ControlVelocityA+=Velcity_Kp*(Bias-Last_biasA)+Velcity_Ki*Bias;  
                                                                   //Velcity_Kp*(Bias-Last_bias)
	                                                                 //Velcity_Ki*Bias            
		Last_biasA=Bias;	
	    if(ControlVelocityA>7000) ControlVelocityA=7000;
	    else if(ControlVelocityA<-7000) ControlVelocityA=-7000;
		return ControlVelocityA; //
}

int Velocity_B(int TargetVelocity, int CurrentVelocity)
{  
    int Bias;  //
		static int ControlVelocityB, Last_biasB; //
		
		Bias=TargetVelocity-CurrentVelocity; //
		
		ControlVelocityB+=Velcity_Kp*(Bias-Last_biasB)+Velcity_Ki*Bias;  //
                                                                   //Velcity_Kp*(Bias-Last_bias) 
	                                                                 //Velcity_Ki*Bias             
		Last_biasB=Bias;	
	    if(ControlVelocityB>7000) ControlVelocityB=7000;
	    else if(ControlVelocityB<-7000) ControlVelocityB=-7000;
		return ControlVelocityB; //
}
*/

#ifndef _MOTOR_H
#define _MOTOR_H
#include "ti_msp_dl_config.h"

typedef struct
{
	float kp;
	float ki;
	
	int output;
    int error;
	int last_error;

	int output_min;
	int output_max;

}VelocityPI;

typedef struct
{
	float kp;
	float ki;

	int output;
    int error;
	int last_error;

	int output_min;
	int output_max;

}TurnPI;

typedef struct
{
	float kp;
	float ki;
	float target;       /* 目标角度 (°) */

	float output;
	float error;
	float integral;
	float integral_max;

	int output_min;
	int output_max;
} AnglePI;

/* 这里只声明，不分配存储空间 */
extern VelocityPI A_Motor_PID;
extern VelocityPI B_Motor_PID;
extern TurnPI Turn_A_Motor_PID;
extern TurnPI Turn_B_Motor_PID;
extern AnglePI  Angle_Motor_PID;

int Velocity_A(volatile VelocityPI *pid,int TargetVelocity, int CurrentVelocity);
int Velocity_B(volatile VelocityPI *pid,int TargetVelocity, int CurrentVelocity);
int Turn_A(volatile TurnPI *pid,int TargetVelocity, int CurrentVelocity);
int Turn_B(volatile TurnPI *pid,int TargetVelocity, int CurrentVelocity);
float Angle_Control(volatile AnglePI *pid, float CurrentAngle);
void Set_PWM(int pwma,int pwmb);
int limit_PWM(int value,int low,int high);
void Turn_PID_Clean(volatile TurnPI *pidA,volatile TurnPI *pidB);

#endif

/*
#ifndef _MOTOR_H
#define _MOTOR_H
#include "ti_msp_dl_config.h"
#include "board.h"

int Velocity_A(int TargetVelocity, int CurrentVelocity);
int Velocity_B(int TargetVelocity, int CurrentVelocity);
void Set_PWM(int pwma,int pwmb);
int limit_PWM(int value,int low,int high);

#endif
*/
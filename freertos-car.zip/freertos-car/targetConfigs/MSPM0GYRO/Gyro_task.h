#ifndef GYRO_TASK_H
#define GYRO_TASK_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* 角度结构体（Z轴偏航角） */
struct SAngle
{
    float Yaw;       /* 偏航角, 单位: 度, 范围 -180 ~ 180 */
};
extern struct SAngle stcAngle;

/* 角速度结构体（Z轴） */
struct SGyro
{
    short rawWz;     /* Z轴角速度原始值 */
    float wz;        /* Z轴角速度, 单位: °/s */
};
extern struct SGyro stcGyro;

/* ================================================================
 *  FreeRTOS 任务函数
 * ================================================================ */
void Gyro_Task(void *pvParameters);

/* ================================================================
 *  数据访问接口（其他任务可直接读取）
 * ================================================================ */

/* 返回当前 Yaw 角（Z轴角度），单位：度，范围 -180 ~ 180 */
float Yaw(void);

/* 返回 Z 轴角速度，单位：°/s */
float GyroZ(void);

/* ================================================================
 *  校准命令（需在合适时机调用）
 * ================================================================ */

/* Z 轴角度归零 */
void sendCaliYawCommand(void);

/* 执行偏置校准（校准期间不可移动设备，等待约21秒） */
void performCaliBias(void);

#ifdef __cplusplus
}
#endif

#endif /* GYRO_TASK_H */

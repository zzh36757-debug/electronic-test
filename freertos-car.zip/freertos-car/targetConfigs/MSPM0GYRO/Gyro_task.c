#include "FreeRTOS.h"
#include "task.h"
#include "ti_msp_dl_config.h"
#include "Gyro_task.h"
#include <stdbool.h>

/* ================================================================
 *  单轴陀螺仪协议解析（移植自官方 STM32F103 例程）
 *
 *  数据帧格式（5字节）：
 *    [0]    0x5A   —— 帧头
 *    [1]    Type   —— 0xAA=角速度帧, 0xBB=角度帧
 *    [2]    DataL  —— 数据低字节
 *    [3]    DataH  —— 数据高字节
 *    [4]    Sum    —— 校验和 (byte[0]+byte[1]+byte[2]+byte[3]) & 0xFF
 *
 *  换算公式：
 *    角速度 wz = raw / 32768 * 2000   (°/s)
 *    角度  Yaw = raw / 32768 * 180    (°, 范围 -180~180)
 *
 *  命令帧格式（5字节，帧头 0x55，与数据帧不同！）：
 *    进入配置:   {0x55, 0xAA, 0x13, 0x8E, 0x5F}
 *    Z轴归零:   {0x55, 0xAA, 0x15, 0x00, 0x00}
 *    保存配置:   {0x55, 0xAA, 0x00, 0x00, 0x00}
 *    偏置校准:   {0x55, 0xAA, 0x0A, 0x01, 0x00}
 *
 *  UART0 波特率 = 9600（由 SysConfig 配置）
 * ================================================================ */

/* ---- 全局数据（其他任务可直接读取） ---- */
struct SAngle stcAngle;
struct SGyro  stcGyro;

/* ---- 任务句柄（ISR 通知用） ---- */
static TaskHandle_t xGyroTaskHandle = NULL;

/* ---- 数据包接收标志 ---- */
static volatile bool new_frame = false;

/* ================================================================
 *  逐字节解析函数（ISR 中调用）
 *  返回 true 表示收到完整有效数据包
 * ================================================================ */
static bool CopeSerial2Data(unsigned char ucData)
{
    static unsigned char ucRxBuffer[5];
    static unsigned char ucRxCnt = 0;

    ucRxBuffer[ucRxCnt++] = ucData;

    /* 帧头必须为 0x5A */
    if (ucRxBuffer[0] != 0x5A)
    {
        ucRxCnt = 0;
        return false;
    }

    /* 未收满 5 字节则继续等待 */
    if (ucRxCnt < 5) return false;

    unsigned char sum = 0;

    if (ucRxBuffer[1] == 0xAA)
    {
        /* ---- 角速度帧 ---- */
        /* 校验和 = 前4字节累加的低8位 */
        sum = ucRxBuffer[0] + ucRxBuffer[1] +
              ucRxBuffer[2] + ucRxBuffer[3];

        if (sum == ucRxBuffer[4])
        {
            short wz = (short)((ucRxBuffer[3] << 8) | ucRxBuffer[2]);
            stcGyro.rawWz = wz;
            stcGyro.wz    = (float)wz / 32768.0f * 2000.0f;
            ucRxCnt = 0;
            return true;
        }
    }
    else if (ucRxBuffer[1] == 0xBB)
    {
        /* ---- 角度帧 ---- */
        sum = ucRxBuffer[0] + ucRxBuffer[1] +
              ucRxBuffer[2] + ucRxBuffer[3];

        if (sum == ucRxBuffer[4])
        {
            short rawYaw = (short)((ucRxBuffer[3] << 8) | ucRxBuffer[2]);
            stcAngle.Yaw = (float)rawYaw / 32768.0f * 180.0f;
            ucRxCnt = 0;
            return true;
        }
    }

    /* 校验失败或未知帧类型，重置接收状态 */
    ucRxCnt = 0;
    return false;
}

/* ================================================================
 *  UART0 接收中断服务函数
 *  （替代原 jy61p_task.c 中的 UART_0_INST_IRQHandler）
 * ================================================================ */
void UART_0_INST_IRQHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    if (DL_UART_getPendingInterrupt(UART_0_INST) == DL_UART_IIDX_RX)
    {
        uint8_t ch = DL_UART_Main_receiveData(UART_0_INST);

        if (CopeSerial2Data(ch))
        {
            new_frame = true;
            if (xGyroTaskHandle != NULL)
            {
                vTaskNotifyGiveFromISR(xGyroTaskHandle, &xHigherPriorityTaskWoken);
            }
        }
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

/* ================================================================
 *  发送函数
 * ================================================================ */

/* 发送单个字节（忙等阻塞） */
static void USART0_SendByte(uint8_t byte)
{
    while (DL_UART_isBusy(UART_0_INST) == true);
    DL_UART_Main_transmitData(UART_0_INST, byte);
}

/* 发送多字节 */
static void USART0_SendBytes(uint8_t *data, uint32_t len)
{
    for (uint32_t i = 0; i < len; i++)
    {
        USART0_SendByte(data[i]);
    }
}

/* ================================================================
 *  命令定义（5字节命令，帧头为 0x55，非 0x5A）
 * ================================================================ */

/* 进入配置模式 */
static uint8_t Key[5]      = {0x55, 0xAA, 0x13, 0x8E, 0x5F};

/* Z 轴角度归零 */
static uint8_t Yaw_Zero[5] = {0x55, 0xAA, 0x15, 0x00, 0x00};

/* 保存配置 */
static uint8_t Save[5]     = {0x55, 0xAA, 0x00, 0x00, 0x00};

/* 读取偏置校准 */
static uint8_t BIAS_CAL[5] = {0x55, 0xAA, 0x0A, 0x01, 0x00};

/* ================================================================
 *  Z 轴角度归零命令
 *  调用顺序：进入配置 → Z轴归零 → 保存
 * ================================================================ */
void sendCaliYawCommand(void)
{
    USART0_SendBytes(Key, 5);
    vTaskDelay(pdMS_TO_TICKS(100));
    USART0_SendBytes(Yaw_Zero, 5);
    vTaskDelay(pdMS_TO_TICKS(100));
    USART0_SendBytes(Save, 5);
}

/* ================================================================
 *  执行偏置校准命令
 *  调用顺序：进入配置 → 偏置校准（等21秒） → 保存
 *  注意：校准期间不可移动设备，否则校准失败或效果不佳
 * ================================================================ */
void performCaliBias(void)
{
    USART0_SendBytes(Key, 5);
    vTaskDelay(pdMS_TO_TICKS(100));
    USART0_SendBytes(BIAS_CAL, 5);
    vTaskDelay(pdMS_TO_TICKS(21000));   /* 等待 21 秒校准完成 */
    USART0_SendBytes(Save, 5);
}

/* ================================================================
 *  数据访问接口
 * ================================================================ */

/* 返回 Z 轴角速度（单位：°/s） */
float GyroZ(void)
{
    return stcGyro.wz;
}

/* 返回当前 Yaw 角（Z 轴角度），单位：度，范围 -180 ~ 180 */
float Yaw(void)
{
    return stcAngle.Yaw;
}

/* ================================================================
 *  Gyro 数据处理任务
 *
 *  SYSCFG_DL_UART_0_init() 已在 prvSetupHardware() 中完成：
 *    时钟、GPIO（PA.31=RX, PA.0=TX）、模式、波特率=9600
 *  此处只补开 RX 中断并进入数据接收循环。
 * ================================================================ */
void Gyro_Task(void *pvParameters)
{
    (void)pvParameters;

    xGyroTaskHandle = xTaskGetCurrentTaskHandle();

    /* 使能 UART0 RX 中断 */
    DL_UART_Main_enableInterrupt(UART_0_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_ClearPendingIRQ(UART_0_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_0_INST_INT_IRQN);

    for (;;)
    {
        /* 阻塞等待 ISR 收到完整有效数据包 */
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        /*
         * 数据已在 ISR 的 CopeSerial2Data() 中解析并写入
         * stcAngle / stcGyro，其他任务可直接通过 Yaw() / GyroZ() 读取。
         */
        new_frame = false;
    }
}

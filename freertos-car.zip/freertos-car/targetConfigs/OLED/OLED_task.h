#ifndef OLED_TASK_H
#define OLED_TASK_H
#include "ti_msp_dl_config.h" 

#ifdef __cplusplus
extern "C" {
#endif

/* 任务函数声明 */
void OLEDTask(void *pvParameters);



#ifdef __cplusplus
}
#endif

#endif /* MOTOR_TASK_H */
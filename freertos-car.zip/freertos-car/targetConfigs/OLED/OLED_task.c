#include "OLED_task.h"
#include "FreeRTOS.h"
#include "task.h"
#include "ti_msp_dl_config.h"  // 根据实际硬件驱动调整


#include <stdio.h>
#include "oled_hardware_i2c.h"
#include "../ENCODER/encoder.h"
#include "../ENCODER/encoder_task.h"
#include "../XUNJI/xunji_task.h"
#include "../MOTOR/control_task.h"
//#include "../JY61P/Jy61p_task.h"
#include "../KEY/key.h"
#include "../BEE/bee_task.h"
#include "../ELEMAGNET/elemagnet.h"
#include "../Buletooth/Buletooth_task.h"
#include "../HONGWAIJISHU/hongwai_task.h"
#include "../MSPM0GYRO/Gyro_task.h"

/* 任务主函数 */
void OLEDTask(void *pvParameters)           //从机显示和按键函数
{
    OLED_Init();

   
    /* 任务主循环 */
    for (;;) {        

        uint8_t key1 = Key1_Read();


        OLED_ShowNum(10,2,CH1,1,8);
        OLED_ShowNum(30,2,CH2,1,8);
        OLED_ShowNum(50,2,CH3,1,8);
        OLED_ShowNum(70,2,CH4,1,8);
        OLED_ShowNum(10,6,CH5,1,8);
        OLED_ShowNum(30,6,CH6,1,8);
        OLED_ShowNum(50,6,CH7,1,8);
        OLED_ShowNum(70,6,CH8,1,8);


        /*
                // 显示角度
        OLED_ShowSignedNum(1, 1, (int32_t)Yaw(), 5, 16);
        // 或者直接读结构体
        OLED_ShowSignedNum(1, 5, (int32_t)stcAngle.Yaw, 5, 16);

        OLED_ShowSignedNum(1,3,(int32_t)key1,1,16);
        OLED_ShowString(1,5,(uint8_t *)"ball:",8);
        OLED_ShowNum(50,5,ballcount,5,8);
        OLED_ShowString(1,7,(uint8_t *)"r:",8);
        OLED_ShowNum(30,7,DL_GPIO_readPins(GPIOB, hongwai_jishu1_PIN) ? 1 : 0,1,8);
                OLED_ShowString(1,5,(uint8_t *)"at:",8);
        OLED_ShowSignedNum(50,5,(int32_t)bt_recive1,5,8);
        OLED_ShowString(1,7,(uint8_t *)"BT2:",8);
        OLED_ShowSignedNum(50,7,(int32_t)bt_recive2,5,8);
        OLED_ShowSignedNum(1,1,countA,5,16);
        OLED_ShowSignedNum(60,1,PWM_outA,5,16);
        OLED_ShowSignedNum(60,5,PWM_outB,5,16);
        OLED_ShowSignedNum(1,5,countB,5,16);


        */
        vTaskDelay(pdMS_TO_TICKS(200));
    }
    
    /* 理论上不会执行到这里 */
    vTaskDelete(NULL);
}
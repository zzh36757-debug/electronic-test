#ifndef XUNJI_TASK_H
#define XUNJI_TASK_H

#include "ti_msp_dl_config.h"

extern unsigned char Digtal;

#define CH1 ((Digtal>>0)&0x01)
#define CH2 ((Digtal>>1)&0x01)
#define CH3 ((Digtal>>2)&0x01)
#define CH4 ((Digtal>>3)&0x01)
#define CH5 ((Digtal>>4)&0x01)
#define CH6 ((Digtal>>5)&0x01)
#define CH7 ((Digtal>>6)&0x01)
#define CH8 ((Digtal>>7)&0x01)

#ifdef __cplusplus
extern "C" {
#endif

/* 任务函数声明 */
void XunjiTask(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* XUNJI_TASK_H */
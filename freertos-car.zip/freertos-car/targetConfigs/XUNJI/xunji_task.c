#include "xunji_task.h"
#include "FreeRTOS.h"
#include "task.h"

#include "xunji.h"

/* 校准数据 */
unsigned short white[8]={1800,1800,1800,1800,1800,1800,1800,1800};
unsigned short black[8]={380,380,410,410,380,380,380,380};
/* 传感器实例 */
No_MCU_Sensor sensor;
unsigned char Digtal;

/* 任务主函数 */
void XunjiTask(void *pvParameters)
{
    /* 根据黑白校准值初始化传感器 */
    No_MCU_Ganv_Sensor_Init(&sensor, white, black);

    /* 启动 ADC 转换（使能后必须手动触发第一次转换） */
    DL_ADC12_startConversion(ADC12_0_INST);

    /* 任务主循环 */
    for (;;) {
        /* 无时基传感器常规任务：采集模拟量 + 二值化 + 归一化 */
        No_Mcu_Ganv_Sensor_Task_Without_tick(&sensor);

        /* 获取传感器数字量（8位，每位对应一个传感器，1=白 0=黑） */
        Digtal = Get_Digtal_For_User(&sensor);
        
        /*
         * TODO: 根据 Digtal 做循迹控制逻辑
         * 例如：switch(Digtal) { case 0x18: ... }
         */

        vTaskDelay(pdMS_TO_TICKS(1));   // 1ms 周期 ≈ 裸机 tight loop 频率
    }

    /* 理论上不会执行到这里 */
    vTaskDelete(NULL);
}
#ifndef XUNJI_H_
#define XUNJI_H_
#include <string.h>
#include "ti_msp_dl_config.h"
/**************************** 传感器版本配置 ****************************/
#define Class		    0

/**************************** ADC分辨率配置 ****************************/
#define _14Bits 0     // 14位ADC模式
#define _12Bits 1     // 12位ADC模式
#define _10Bits 2     // 10位ADC模式
#define _8Bits  3     // 8位ADC模式

/**************************** 用户可配置区域 ***************************/
// 传感器版本选择
#define Sensor_Edition Class


/************************* 根据单片机自行选择 **************************/
// 输出结果方向，与预期方向不同选1
#define Direction 1
// ADC分辨率选择（四选一）
// #define Sensor_ADCbits _14Bits
#define Sensor_ADCbits _12Bits
// #define Sensor_ADCbits _10Bits
// #define Sensor_ADCbits _8Bits

/*************************** 硬件抽象层配置 ****************************/
// GPIO地址切换宏定义
#define Switch_Address_0(i) ((i)?(DL_GPIO_setPins(Gray_Address_PORT,Gray_Address_PIN_0_PIN)) : (DL_GPIO_clearPins(Gray_Address_PORT,Gray_Address_PIN_0_PIN)))// 地址位0控制

#define Switch_Address_1(i) ((i)?(DL_GPIO_setPins(Gray_Address_PORT,Gray_Address_PIN_1_PIN)) : (DL_GPIO_clearPins(Gray_Address_PORT,Gray_Address_PIN_1_PIN)))// 地址位1控制

#define Switch_Address_2(i) ((i)?(DL_GPIO_setPins(Gray_Address_PORT,Gray_Address_PIN_2_PIN)) : (DL_GPIO_clearPins(Gray_Address_PORT,Gray_Address_PIN_2_PIN)))// 地址位2控制

// ADC值获取接口（匹配裸机：每次触发→等待→读取，保证数据对应当前通道）
static inline unsigned short Get_adc_of_user(void)
{
    /* 清除上次完成标志，等待下一次转换结束 */
    DL_ADC12_clearInterruptStatus(ADC12_0_INST, DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED);
    while (!DL_ADC12_getRawInterruptStatus(ADC12_0_INST, DL_ADC12_INTERRUPT_MEM0_RESULT_LOADED)) {
        /* 等待转换完成（约 5.5µs） */
    }
    return DL_ADC12_getMemResult(ADC12_0_INST, ADC12_0_ADCMEM_0);
}

// 微秒级延时（CPUCLK_FREQ=80MHz，每微秒80周期）
static inline void delay_us(unsigned int us)
{
    DL_Common_delayCycles(us * (CPUCLK_FREQ / 1000000));
}
/**********************************************************************/

/*************************** 传感器数据结构 ***************************/
typedef struct {
    unsigned short Analog_value[8];    // 原始模拟量值
    unsigned short Normal_value[8];   // 归一化后的值
    unsigned short Calibrated_white[8]; // 白校准基准值
    unsigned short Calibrated_black[8]; // 黑校准基准值
    unsigned short Gray_white[8];      // 白平衡灰度值
    unsigned short Gray_black[8];      // 黑平衡灰度值
    double Normal_factor[8];          // 归一化系数
    double bits;                      // ADC分辨率对应位数
    unsigned char Digtal;              // 数字输出状态
    unsigned char Time_out;            // 超时标志
    unsigned char Tick;                // 时基计数器
    unsigned char ok;                  // 传感器就绪标志
} No_MCU_Sensor;

#ifdef __cplusplus
extern "C" {
#endif

/*************************** 函数声明区域 *****************************/
// 底层采集函数
void Get_Analog_value(unsigned short *result);
void convertAnalogToDigital(unsigned short *adc_value, unsigned short *Gray_white, unsigned short *Gray_black, unsigned char *Digital);
void normalizeAnalogValues(unsigned short *adc_value, double *Normal_factor, unsigned short *Calibrated_black, unsigned short *result, double bits);

// 初始化函数
void No_MCU_Ganv_Sensor_Init_Frist(No_MCU_Sensor* sensor); // 首次初始化
void No_MCU_Ganv_Sensor_Init(No_MCU_Sensor* sensor,unsigned short* Calibrated_white, unsigned short* Calibrated_black);// 带校准参数的初始化

// 任务处理函数
void No_Mcu_Ganv_Sensor_Task_Without_tick(No_MCU_Sensor* sensor); // 无时基版本

// 用户接口函数
unsigned char Get_Digtal_For_User(No_MCU_Sensor* sensor);          									// 获取数字量
unsigned char Get_Normalize_For_User(No_MCU_Sensor* sensor,unsigned short* result); // 获取归一化值
unsigned char Get_Anolog_Value(No_MCU_Sensor* sensor,unsigned short* result);       // 获取模拟值

#ifdef __cplusplus
}
#endif

#endif /* XUNJI_H_ */

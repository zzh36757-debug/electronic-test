#include "FreeRTOS.h"
#include "task.h"
#include "ti_msp_dl_config.h"
#include "Uart2_task.h"
#include <stdio.h>

/* 接收缓冲区 */
char uart2_rx_buf[UART2_RX_BUF_SIZE];
volatile uint8_t uart2_rx_index = 0;
volatile bool uart2_new_data = false;

/* 解析结果，全局变量，其他任务可读取 */
volatile int g_uart_angleX = 0;
volatile int g_uart_angleY = 0;

/* UART任务句柄，供ISR唤醒任务使用 */
static TaskHandle_t xUart2TaskHandle = NULL;

/* 串口发送单个字符 */
void uart2_send_char(char ch)
{
    while (DL_UART_isBusy(UART_2_INST) == true);
    DL_UART_Main_transmitData(UART_2_INST, ch);
}

/* 串口发送字符串 */
void uart2_send_string(char *str)
{
    while (*str != 0 && str != 0)
    {
        uart2_send_char(*str++);
    }
}

/* UART2 接收中断服务函数 */
void UART_2_INST_IRQHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    if (DL_UART_getPendingInterrupt(UART_2_INST) == DL_UART_IIDX_RX)
    {
        char ch = DL_UART_Main_receiveData(UART_2_INST);

        /* 收到换行符，一帧结束 */
        if (ch == '\n')
        {
            if (uart2_rx_index < UART2_RX_BUF_SIZE)
                uart2_rx_buf[uart2_rx_index] = '\0';
            uart2_new_data = true;
            uart2_rx_index = 0;

            /* 通过任务通知唤醒UART处理任务 */
            if (xUart2TaskHandle != NULL)
            {
                vTaskNotifyGiveFromISR(xUart2TaskHandle, &xHigherPriorityTaskWoken);
            }
        }
        else
        {
            /* 存储常规字符 */
            if (uart2_rx_index < UART2_RX_BUF_SIZE - 1)
            {
                uart2_rx_buf[uart2_rx_index++] = ch;
            }
            else
            {
                /* 缓冲区溢出，丢弃 */
                uart2_rx_index = 0;
                uart2_new_data = false;
            }
        }
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

/* UART2 接收处理任务 */
void Uart2_Task(void *pvParameters)
{
    char *p;

    /* RX引脚使能内部上拉，防止浮空时噪声触发假起始位导致BUSY死锁 */
    DL_GPIO_initPeripheralInputFunctionFeatures(GPIO_UART_2_IOMUX_RX,
        GPIO_UART_2_IOMUX_RX_FUNC, DL_GPIO_INVERSION_DISABLE,
        DL_GPIO_RESISTOR_PULL_UP, DL_GPIO_HYSTERESIS_DISABLE,
        DL_GPIO_WAKEUP_DISABLE);

    /* 保存任务句柄，供ISR使用 */
    xUart2TaskHandle = xTaskGetCurrentTaskHandle();

    /*
     * 使能UART RX中断。
     * 注意：SysConfig生成的 SYSCFG_DL_UART_2_init() 没有开启RX中断，
     * 需要在这里手动开启。
     */
    DL_UART_Main_enableInterrupt(UART_2_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_ClearPendingIRQ(UART_2_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_2_INST_INT_IRQN);

    /* 启动确认：发送一条消息验证 TX 和任务都正常 */
    uart2_send_string("UART Start\n");

    for (;;)
    {
        /* 阻塞等待ISR发来的任务通知 */
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        if (uart2_new_data)
        {
            /* 去掉末尾的 \r（串口助手通常发 \r\n） */
            for (p = uart2_rx_buf; *p != '\0'; p++)
            {
                if (*p == '\r') { *p = '\0'; break; }
            }

            if (sscanf(uart2_rx_buf, "X:%d Y:%d", &g_uart_angleX, &g_uart_angleY) == 2)
            {
                char msg[32];
                sprintf(msg, "OK X:%d Y:%d\n", g_uart_angleX, g_uart_angleY);
                uart2_send_string(msg);
            }
            else
            {
                /* 格式不对，回显收到的内容帮助调试 */
                uart2_send_string("ERR got:[");
                uart2_send_string(uart2_rx_buf);
                uart2_send_string("]\n");
            }

            uart2_new_data = false;
        }
    }
}

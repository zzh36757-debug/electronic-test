#ifndef UART2_TASK_H
#define UART2_TASK_H

#include "ti_msp_dl_config.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define UART2_RX_BUF_SIZE 64

/* 共享接收缓冲区（ISR写入，任务读取） */
extern char uart2_rx_buf[UART2_RX_BUF_SIZE];
extern volatile bool uart2_new_data;

/* 解析后的坐标值（UART任务写入，其他任务只读） */
extern volatile int g_uart_angleX;
extern volatile int g_uart_angleY;

/* 发送函数 */
void uart2_send_char(char ch);
void uart2_send_string(char *str);

/* 任务函数 */
void Uart2_Task(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* UART2_TASK_H */

#ifndef ENCODER_H
#define ENCODER_H

#include "ti_msp_dl_config.h"
#include "FreeRTOS.h"
#include "task.h"

/* 编码器计数值 */
extern volatile int Get_Encoder_countA;
extern volatile int Get_Encoder_countB;

void GROUP1_IRQHandler(void);
void Encoder_Init(void);

#endif

#ifndef ENCODER_TASK_H
#define ENCODER_TASK_H

#include "FreeRTOS.h"
#include "task.h"
#include "encoder.h"

extern volatile int countA;
extern volatile int countB;
void EncoderTask(void *pvParameters);

#endif

#include "encoder_task.h"
#include "encoder.h"

volatile int countA, countB;

void EncoderTask(void *pvParameters)
{
    for (;;) {
        vTaskDelay(pdMS_TO_TICKS(10));

        

        /* 关中断 → 读数 → 清零 → 开中断（防止 ISR 插队丢脉冲）*/
        taskENTER_CRITICAL();
        countA = Get_Encoder_countA;
        countB = Get_Encoder_countB;
        Get_Encoder_countA = 0;
        Get_Encoder_countB = 0;
        taskEXIT_CRITICAL();

        if (countA != 0) {
            /* TODO: countA = 这10ms内编码器A的脉冲数 */
        }
        if (countB != 0) {
            /* TODO: countB = 这10ms内编码器B的脉冲数 */
        }
    }
}

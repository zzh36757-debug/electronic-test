#include "encoder.h"

volatile int Get_Encoder_countA = 0;
volatile int Get_Encoder_countB = 0;

/* SysConfig 漏了 NVIC 使能 */
void Encoder_Init(void)
{
    NVIC_EnableIRQ(GPIOA_INT_IRQn);
    NVIC_EnableIRQ(GPIOB_INT_IRQn);
}

void GROUP1_IRQHandler(void)
{
    uint32_t gpio_interrup1, gpio_interrup2;

    gpio_interrup1 = DL_GPIO_getEnabledInterruptStatus(ENCODERA_PORT,
                         ENCODERA_E1A_PIN | ENCODERA_E1B_PIN);
    gpio_interrup2 = DL_GPIO_getEnabledInterruptStatus(ENCODERB_PORT,
                         ENCODERB_E2A_PIN | ENCODERB_E2B_PIN);

    //encoderA
    if ((gpio_interrup1 & ENCODERA_E1A_PIN) == ENCODERA_E1A_PIN) {
        if (!DL_GPIO_readPins(ENCODERA_PORT, ENCODERA_E1B_PIN)) {
            Get_Encoder_countA--;
        } else {
            Get_Encoder_countA++;
        }
    }
    else if ((gpio_interrup1 & ENCODERA_E1B_PIN) == ENCODERA_E1B_PIN) {
        if (!DL_GPIO_readPins(ENCODERA_PORT, ENCODERA_E1A_PIN)) {
            Get_Encoder_countA++;
        } else {
            Get_Encoder_countA--;
        }
    }

    //encoderB
    if ((gpio_interrup2 & ENCODERB_E2A_PIN) == ENCODERB_E2A_PIN) {
        if (!DL_GPIO_readPins(ENCODERB_PORT, ENCODERB_E2B_PIN)) {
            Get_Encoder_countB--;
        } else {
            Get_Encoder_countB++;
        }
    }
    else if ((gpio_interrup2 & ENCODERB_E2B_PIN) == ENCODERB_E2B_PIN) {
        if (!DL_GPIO_readPins(ENCODERB_PORT, ENCODERB_E2A_PIN)) {
            Get_Encoder_countB++;
        } else {
            Get_Encoder_countB--;
        }
    }

    DL_GPIO_clearInterruptStatus(ENCODERA_PORT,
        ENCODERA_E1A_PIN | ENCODERA_E1B_PIN);
    DL_GPIO_clearInterruptStatus(ENCODERB_PORT,
        ENCODERB_E2A_PIN | ENCODERB_E2B_PIN);
}

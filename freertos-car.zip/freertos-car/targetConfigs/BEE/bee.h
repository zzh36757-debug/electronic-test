#ifndef BEE_H
#define BEE_H

#include "ti_msp_dl_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 蜂鸣器引脚 */
#define BEE_PORT   Bee_PORT
#define BEE_PIN    Bee_Load_PIN

/* 基本控制 */
void Bee_On(void);        /* 蜂鸣器开 */
void Bee_Off(void);       /* 蜂鸣器关 */
void Bee_Toggle(void);    /* 翻转 */

#ifdef __cplusplus
}
#endif

#endif /* BEE_H */

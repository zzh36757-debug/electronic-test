#ifndef BEE_TASK_H
#define BEE_TASK_H

#include "FreeRTOS.h"
#include "task.h"
#include "ti_msp_dl_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 蜂鸣器任务句柄，其他任务通过它来控制蜂鸣器 */
extern TaskHandle_t xBeeTaskHandle;

/* 蜂鸣时间（ms），其他任务设置这个值来触发蜂鸣 */
extern volatile uint32_t g_bee_duration_ms;

/* 任务函数 */
void Bee_Task(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* BEE_TASK_H */

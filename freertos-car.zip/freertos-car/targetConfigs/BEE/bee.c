#include "bee.h"

void Bee_On(void)
{
    DL_GPIO_clearPins(BEE_PORT, BEE_PIN);
}

void Bee_Off(void)
{
    DL_GPIO_setPins(BEE_PORT, BEE_PIN);
}

void Bee_Toggle(void)
{
    DL_GPIO_togglePins(BEE_PORT, BEE_PIN);
}

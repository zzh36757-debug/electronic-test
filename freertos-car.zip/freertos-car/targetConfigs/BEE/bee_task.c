#include "bee_task.h"
#include "bee.h"
#include "FreeRTOS.h"
#include "task.h"

TaskHandle_t xBeeTaskHandle = NULL;
volatile uint32_t g_bee_duration_ms = 0;

void Bee_Task(void *pvParameters)
{
    xBeeTaskHandle = xTaskGetCurrentTaskHandle();
    Bee_Off();   /* 初始关闭 */

    for (;;)
    {
        /* 等待其他任务发来蜂鸣指令 */
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        if (g_bee_duration_ms > 0)
        {
            Bee_On();
            vTaskDelay(pdMS_TO_TICKS(g_bee_duration_ms));
            Bee_Off();
            g_bee_duration_ms = 0;
        }
        else
        {
            /* duration=0 表示立即关断 */
            Bee_Off();
            g_bee_duration_ms = 0;
        }
    }
}

#include "hongwai_task.h"
#include "FreeRTOS.h"
#include "task.h"
#include "ti_msp_dl_config.h"

volatile uint32_t ballcount = 0;

/* ================================================================
 * 红外计数任务（高电平有效，轮询方式）
 * 5ms 轮询 GPIO，上升沿（LOW→HIGH）时 ballcount++。
 * 自带消抖：检测到边沿后跳过 2 个周期（10ms）避免重复计数。
 * ================================================================ */
void HongwaiTask(void *pvParameters)
{
    uint8_t  last_level = 0;
    uint8_t  curr_level;
    uint8_t  debounce   = 0;

    /* 关掉 syscfg 生成的中断，避免跟编码器抢 GROUP1_IRQHandler */
    DL_GPIO_disableInterrupt(IR_SENSOR_PORT, IR_SENSOR_PIN);
    DL_GPIO_clearInterruptStatus(IR_SENSOR_PORT, IR_SENSOR_PIN);

    for (;;) {
        curr_level = DL_GPIO_readPins(IR_SENSOR_PORT, IR_SENSOR_PIN) ? 1 : 0;

        if (debounce > 0) {
            debounce--;
        } else if (curr_level && !last_level) {
            /* 上升沿（LOW→HIGH）：物体进入红外检测区域 */
            ballcount++;
            debounce = 2;
        }

        last_level = curr_level;
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}

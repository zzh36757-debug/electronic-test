#ifndef _HONGWAI_TASK_H
#define _HONGWAI_TASK_H

#include <stdint.h>
#include "ti_msp_dl_config.h"   /* 使用 syscfg 生成的红外引脚宏 */

/* 红外计数器（全局变量，OLED任务可直接读取） */
extern volatile uint32_t ballcount;

/* syscfg 中已配置：hongwai_jishu1 → GPIOB Pin26 */
#define IR_SENSOR_PORT   GPIOB
#define IR_SENSOR_PIN    hongwai_jishu1_PIN

void HongwaiTask(void *pvParameters);

#endif

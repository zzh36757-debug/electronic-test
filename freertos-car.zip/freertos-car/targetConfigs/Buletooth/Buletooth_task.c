#include "FreeRTOS.h"
#include "task.h"
#include "ti_msp_dl_config.h"
#include "Buletooth_task.h"
#include <stdio.h>

/* 接收缓冲区 */
char bt_rx_buf[BT_RX_BUF_SIZE];
volatile uint8_t bt_rx_index = 0;
volatile bool bt_new_data = false;

/* 解析结果，全局变量，其他任务可读取 */
volatile int bt_recive1 = 0;
volatile int bt_recive2 = 0;

/* 任务句柄，供ISR唤醒任务使用 */
static TaskHandle_t xBuletoothTaskHandle = NULL;

/* 发送单个字符 */
void bt_send_char(char ch)
{
    while (DL_UART_isBusy(UART_1_INST) == true);
    DL_UART_Main_transmitData(UART_1_INST, ch);
}

/* 发送字符串 */
void bt_send_string(char *str)
{
    while (*str != 0 && str != 0)
    {
        bt_send_char(*str++);
    }
}

/* UART1 接收中断服务函数 */
void UART_1_INST_IRQHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    if (DL_UART_getPendingInterrupt(UART_1_INST) == DL_UART_IIDX_RX)
    {
        char ch = DL_UART_Main_receiveData(UART_1_INST);

        /* 收到换行符，一帧结束 */
        if (ch == '\n')
        {
            if (bt_rx_index < BT_RX_BUF_SIZE)
                bt_rx_buf[bt_rx_index] = '\0';
            bt_new_data = true;
            bt_rx_index = 0;

            /* 通过任务通知唤醒蓝牙处理任务 */
            if (xBuletoothTaskHandle != NULL)
            {
                vTaskNotifyGiveFromISR(xBuletoothTaskHandle, &xHigherPriorityTaskWoken);
            }
        }
        else
        {
            /* 存储常规字符 */
            if (bt_rx_index < BT_RX_BUF_SIZE - 1)
            {
                bt_rx_buf[bt_rx_index++] = ch;
            }
            else
            {
                /* 缓冲区溢出，丢弃 */
                bt_rx_index = 0;
                bt_new_data = false;
            }
        }
    }

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

/* 蓝牙接收处理任务 */
void Buletooth_Task(void *pvParameters)
{
    char *p;

    /* 保存任务句柄，供ISR使用 */
    xBuletoothTaskHandle = xTaskGetCurrentTaskHandle();

    /*
     * 使能UART1 RX中断。
     */
    DL_UART_Main_enableInterrupt(UART_1_INST, DL_UART_MAIN_INTERRUPT_RX);
    NVIC_ClearPendingIRQ(UART_1_INST_INT_IRQN);
    NVIC_EnableIRQ(UART_1_INST_INT_IRQN);

    /* 启动确认 */
    bt_send_string("BT UART1 Start\n");

    for (;;)
    {
        /* 阻塞等待ISR发来的任务通知 */
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        if (bt_new_data)
        {
            /* 去掉末尾的 \r */
            for (p = bt_rx_buf; *p != '\0'; p++)
            {
                if (*p == '\r') { *p = '\0'; break; }
            }

            /* 解析数据：支持 "1:xxx 2:yyy" 或 "xxx,yyy" 两种格式 */
            if (sscanf(bt_rx_buf, "1:%d 2:%d", &bt_recive1, &bt_recive2) == 2)
            {
                char msg[48];
                sprintf(msg, "OK 1:%d 2:%d\n", bt_recive1, bt_recive2);
                bt_send_string(msg);
            }
            else if (sscanf(bt_rx_buf, "%d,%d", &bt_recive1, &bt_recive2) == 2)
            {
                char msg[48];
                sprintf(msg, "OK 1:%d 2:%d\n", bt_recive1, bt_recive2);
                bt_send_string(msg);
            }
            else
            {
                /* 格式不对，回显收到的内容帮助调试 */
                bt_send_string("ERR got:[");
                bt_send_string(bt_rx_buf);
                bt_send_string("]\n");
            }

            bt_new_data = false;
        }
    }
}

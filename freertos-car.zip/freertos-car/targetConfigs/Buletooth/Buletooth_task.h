#ifndef BULETOOTH_TASK_H
#define BULETOOTH_TASK_H

#include "ti_msp_dl_config.h"
#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

#define BT_RX_BUF_SIZE 128

/* 共享接收缓冲区（ISR写入，任务读取） */
extern char bt_rx_buf[BT_RX_BUF_SIZE];
extern volatile bool bt_new_data;

/* 解析后的蓝牙数据（蓝牙任务写入，其他任务只读） */
extern volatile int bt_recive1;
extern volatile int bt_recive2;

/* 发送函数 */
void bt_send_char(char ch);
void bt_send_string(char *str);

/* 任务函数 */
void Buletooth_Task(void *pvParameters);

#ifdef __cplusplus
}
#endif

#endif /* BULETOOTH_TASK_H */

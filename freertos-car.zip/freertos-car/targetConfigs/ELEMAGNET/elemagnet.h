#ifndef ELEMAGNET_H
#define ELEMAGNET_H

#include "ti_msp_dl_config.h"

#ifdef __cplusplus
extern "C" {
#endif

/* 电磁铁引脚：PB12 */
#define ELEMAGNET_PORT   elemagnet_PORT
#define ELEMAGNET_PIN    elemagnet_PIN_3_PIN

void Elemagnet_On(void);     /* HIGH → 吸合 */
void Elemagnet_Off(void);    /* LOW  → 释放 */

#ifdef __cplusplus
}
#endif

#endif /* ELEMAGNET_H */

#include "elemagnet.h"

/* 高电平 → 继电器吸合 → 电磁铁通电 */
void Elemagnet_On(void)
{
    DL_GPIO_setPins(ELEMAGNET_PORT, ELEMAGNET_PIN);
}

/* 低电平 → 继电器断开 → 电磁铁断电 */
void Elemagnet_Off(void)
{
    DL_GPIO_clearPins(ELEMAGNET_PORT, ELEMAGNET_PIN);
}

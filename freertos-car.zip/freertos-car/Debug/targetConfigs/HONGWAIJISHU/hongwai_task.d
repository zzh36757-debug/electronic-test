# FIXED

targetConfigs/HONGWAIJISHU/hongwai_task.o: \
 ../targetConfigs/HONGWAIJISHU/hongwai_task.c \
 ../targetConfigs/HONGWAIJISHU/hongwai_task.h \
 syscfg/ti_msp_dl_config.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/driverlib.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_adc12.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_common.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_factoryregion.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_core.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aes.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aesadv.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_comp.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crc.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crcp.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dac12.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dma.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_flashctl.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_sysctl.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpamp.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpio.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2c.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2s.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_iwdt.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lfss.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_keystorectl.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lcd.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mathacl.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mcan.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_npu.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_opa.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_common.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_a.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_b.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_scratchpad.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spgss.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spi.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_tamperio.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timera.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timer.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerb.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerg.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_trng.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_extend.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_main.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicomm.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2cc.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2ct.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommspi.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommuart.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_vref.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_wwdt.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_interrupt.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_systick.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/FreeRTOS.h \
 C:/Users/30952/workspace_ccstheia/freertos_builds_LP_MSPM0G3507_release_ticlang/FreeRTOSConfig.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/posix/freertos/PTLS.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/projdefs.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/portable.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/deprecated_definitions.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/portable/TI_ARM_CLANG/ARM_CM0/portmacro.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/mpu_wrappers.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/task.h \
 D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/list.h
../targetConfigs/HONGWAIJISHU/hongwai_task.h:
syscfg/ti_msp_dl_config.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/msp.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/DeviceFamily.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/m0p/mspm0g350x.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include/core_cm0plus.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_adc12.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_aes.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_comp.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_crc.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dac12.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_dma.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_flashctl.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gpio.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_gptimer.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_i2c.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_iomux.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mathacl.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_mcan.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_oa.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_rtc.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_spi.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_trng.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_uart.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_vref.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wuc.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/hw_wwdt.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_factoryregion.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_cpuss.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_debugss.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/hw_sysctl.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/devices/msp/peripherals/m0p/sysctl/hw_sysctl_mspm0g1x0x_g3x0x.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/driverlib.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_adc12.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_common.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_factoryregion.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_core.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aes.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_aesadv.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_comp.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crc.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_crcp.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dac12.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_dma.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_flashctl.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_sysctl.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/sysctl/dl_sysctl_mspm0g1x0x_g3x0x.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpamp.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_gpio.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2c.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_i2s.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_iwdt.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lfss.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_keystorectl.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_lcd.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mathacl.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_mcan.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_npu.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_opa.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_common.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_a.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_rtc_b.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_scratchpad.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spgss.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_spi.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_tamperio.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timera.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timer.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerb.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_timerg.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_trng.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_extend.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_uart_main.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicomm.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2cc.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommi2ct.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommspi.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_unicommuart.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_vref.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/dl_wwdt.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_interrupt.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/driverlib/m0p/dl_systick.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/FreeRTOS.h:
C:/Users/30952/workspace_ccstheia/freertos_builds_LP_MSPM0G3507_release_ticlang/FreeRTOSConfig.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/posix/freertos/PTLS.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/projdefs.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/portable.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/deprecated_definitions.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/portable/TI_ARM_CLANG/ARM_CM0/portmacro.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/mpu_wrappers.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/task.h:
D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include/list.h:

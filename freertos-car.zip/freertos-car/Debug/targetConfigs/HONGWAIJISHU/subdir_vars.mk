################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/HONGWAIJISHU/hongwai_task.c 

C_DEPS += \
./targetConfigs/HONGWAIJISHU/hongwai_task.d 

OBJS += \
./targetConfigs/HONGWAIJISHU/hongwai_task.o 

OBJS__QUOTED += \
"targetConfigs\HONGWAIJISHU\hongwai_task.o" 

C_DEPS__QUOTED += \
"targetConfigs\HONGWAIJISHU\hongwai_task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/HONGWAIJISHU/hongwai_task.c" 



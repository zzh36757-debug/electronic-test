################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/ELEMAGNET/elemagnet.c 

C_DEPS += \
./targetConfigs/ELEMAGNET/elemagnet.d 

OBJS += \
./targetConfigs/ELEMAGNET/elemagnet.o 

OBJS__QUOTED += \
"targetConfigs\ELEMAGNET\elemagnet.o" 

C_DEPS__QUOTED += \
"targetConfigs\ELEMAGNET\elemagnet.d" 

C_SRCS__QUOTED += \
"../targetConfigs/ELEMAGNET/elemagnet.c" 



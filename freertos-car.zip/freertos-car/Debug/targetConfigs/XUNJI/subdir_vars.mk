################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/XUNJI/xunji.c \
../targetConfigs/XUNJI/xunji_task.c 

C_DEPS += \
./targetConfigs/XUNJI/xunji.d \
./targetConfigs/XUNJI/xunji_task.d 

OBJS += \
./targetConfigs/XUNJI/xunji.o \
./targetConfigs/XUNJI/xunji_task.o 

OBJS__QUOTED += \
"targetConfigs\XUNJI\xunji.o" \
"targetConfigs\XUNJI\xunji_task.o" 

C_DEPS__QUOTED += \
"targetConfigs\XUNJI\xunji.d" \
"targetConfigs\XUNJI\xunji_task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/XUNJI/xunji.c" \
"../targetConfigs/XUNJI/xunji_task.c" 



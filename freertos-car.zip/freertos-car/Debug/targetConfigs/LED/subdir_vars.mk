################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/LED/LED.c \
../targetConfigs/LED/LED_Task.c 

C_DEPS += \
./targetConfigs/LED/LED.d \
./targetConfigs/LED/LED_Task.d 

OBJS += \
./targetConfigs/LED/LED.o \
./targetConfigs/LED/LED_Task.o 

OBJS__QUOTED += \
"targetConfigs\LED\LED.o" \
"targetConfigs\LED\LED_Task.o" 

C_DEPS__QUOTED += \
"targetConfigs\LED\LED.d" \
"targetConfigs\LED\LED_Task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/LED/LED.c" \
"../targetConfigs/LED/LED_Task.c" 



################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/Buletooth.c 

C_DEPS += \
./targetConfigs/Buletooth.d 

OBJS += \
./targetConfigs/Buletooth.o 

OBJS__QUOTED += \
"targetConfigs\Buletooth.o" 

C_DEPS__QUOTED += \
"targetConfigs\Buletooth.d" 

C_SRCS__QUOTED += \
"../targetConfigs/Buletooth.c" 



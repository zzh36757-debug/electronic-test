################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/MOTOR/control_task.c \
../targetConfigs/MOTOR/motor.c 

C_DEPS += \
./targetConfigs/MOTOR/control_task.d \
./targetConfigs/MOTOR/motor.d 

OBJS += \
./targetConfigs/MOTOR/control_task.o \
./targetConfigs/MOTOR/motor.o 

OBJS__QUOTED += \
"targetConfigs\MOTOR\control_task.o" \
"targetConfigs\MOTOR\motor.o" 

C_DEPS__QUOTED += \
"targetConfigs\MOTOR\control_task.d" \
"targetConfigs\MOTOR\motor.d" 

C_SRCS__QUOTED += \
"../targetConfigs/MOTOR/control_task.c" \
"../targetConfigs/MOTOR/motor.c" 



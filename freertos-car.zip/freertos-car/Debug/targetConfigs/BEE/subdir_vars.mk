################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/BEE/bee.c \
../targetConfigs/BEE/bee_task.c 

C_DEPS += \
./targetConfigs/BEE/bee.d \
./targetConfigs/BEE/bee_task.d 

OBJS += \
./targetConfigs/BEE/bee.o \
./targetConfigs/BEE/bee_task.o 

OBJS__QUOTED += \
"targetConfigs\BEE\bee.o" \
"targetConfigs\BEE\bee_task.o" 

C_DEPS__QUOTED += \
"targetConfigs\BEE\bee.d" \
"targetConfigs\BEE\bee_task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/BEE/bee.c" \
"../targetConfigs/BEE/bee_task.c" 



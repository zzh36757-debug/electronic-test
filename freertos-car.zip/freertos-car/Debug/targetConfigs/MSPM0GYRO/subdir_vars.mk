################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/MSPM0GYRO/Gyro_task.c 

C_DEPS += \
./targetConfigs/MSPM0GYRO/Gyro_task.d 

OBJS += \
./targetConfigs/MSPM0GYRO/Gyro_task.o 

OBJS__QUOTED += \
"targetConfigs\MSPM0GYRO\Gyro_task.o" 

C_DEPS__QUOTED += \
"targetConfigs\MSPM0GYRO\Gyro_task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/MSPM0GYRO/Gyro_task.c" 



################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/CAN/Emm_V5.c \
../targetConfigs/CAN/Emm_V5_task.c \
../targetConfigs/CAN/can.c 

C_DEPS += \
./targetConfigs/CAN/Emm_V5.d \
./targetConfigs/CAN/Emm_V5_task.d \
./targetConfigs/CAN/can.d 

OBJS += \
./targetConfigs/CAN/Emm_V5.o \
./targetConfigs/CAN/Emm_V5_task.o \
./targetConfigs/CAN/can.o 

OBJS__QUOTED += \
"targetConfigs\CAN\Emm_V5.o" \
"targetConfigs\CAN\Emm_V5_task.o" \
"targetConfigs\CAN\can.o" 

C_DEPS__QUOTED += \
"targetConfigs\CAN\Emm_V5.d" \
"targetConfigs\CAN\Emm_V5_task.d" \
"targetConfigs\CAN\can.d" 

C_SRCS__QUOTED += \
"../targetConfigs/CAN/Emm_V5.c" \
"../targetConfigs/CAN/Emm_V5_task.c" \
"../targetConfigs/CAN/can.c" 



################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/JY61P/jy61p_task.c 

C_DEPS += \
./targetConfigs/JY61P/jy61p_task.d 

OBJS += \
./targetConfigs/JY61P/jy61p_task.o 

OBJS__QUOTED += \
"targetConfigs\JY61P\jy61p_task.o" 

C_DEPS__QUOTED += \
"targetConfigs\JY61P\jy61p_task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/JY61P/jy61p_task.c" 



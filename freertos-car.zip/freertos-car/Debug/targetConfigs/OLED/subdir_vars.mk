################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/OLED/OLED_task.c \
../targetConfigs/OLED/oled_hardware_i2c.c 

C_DEPS += \
./targetConfigs/OLED/OLED_task.d \
./targetConfigs/OLED/oled_hardware_i2c.d 

OBJS += \
./targetConfigs/OLED/OLED_task.o \
./targetConfigs/OLED/oled_hardware_i2c.o 

OBJS__QUOTED += \
"targetConfigs\OLED\OLED_task.o" \
"targetConfigs\OLED\oled_hardware_i2c.o" 

C_DEPS__QUOTED += \
"targetConfigs\OLED\OLED_task.d" \
"targetConfigs\OLED\oled_hardware_i2c.d" 

C_SRCS__QUOTED += \
"../targetConfigs/OLED/OLED_task.c" \
"../targetConfigs/OLED/oled_hardware_i2c.c" 



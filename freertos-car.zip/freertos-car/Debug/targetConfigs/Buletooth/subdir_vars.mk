################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/Buletooth/Buletooth_task.c 

C_DEPS += \
./targetConfigs/Buletooth/Buletooth_task.d 

OBJS += \
./targetConfigs/Buletooth/Buletooth_task.o 

OBJS__QUOTED += \
"targetConfigs\Buletooth\Buletooth_task.o" 

C_DEPS__QUOTED += \
"targetConfigs\Buletooth\Buletooth_task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/Buletooth/Buletooth_task.c" 



################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/UART/Uart2_task.c 

C_DEPS += \
./targetConfigs/UART/Uart2_task.d 

OBJS += \
./targetConfigs/UART/Uart2_task.o 

OBJS__QUOTED += \
"targetConfigs\UART\Uart2_task.o" 

C_DEPS__QUOTED += \
"targetConfigs\UART\Uart2_task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/UART/Uart2_task.c" 



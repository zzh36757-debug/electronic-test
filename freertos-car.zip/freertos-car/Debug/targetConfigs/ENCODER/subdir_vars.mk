################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/ENCODER/encoder.c \
../targetConfigs/ENCODER/encoder_task.c 

C_DEPS += \
./targetConfigs/ENCODER/encoder.d \
./targetConfigs/ENCODER/encoder_task.d 

OBJS += \
./targetConfigs/ENCODER/encoder.o \
./targetConfigs/ENCODER/encoder_task.o 

OBJS__QUOTED += \
"targetConfigs\ENCODER\encoder.o" \
"targetConfigs\ENCODER\encoder_task.o" 

C_DEPS__QUOTED += \
"targetConfigs\ENCODER\encoder.d" \
"targetConfigs\ENCODER\encoder_task.d" 

C_SRCS__QUOTED += \
"../targetConfigs/ENCODER/encoder.c" \
"../targetConfigs/ENCODER/encoder_task.c" 



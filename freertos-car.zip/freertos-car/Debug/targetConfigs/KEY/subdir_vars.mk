################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../targetConfigs/KEY/key.c 

C_DEPS += \
./targetConfigs/KEY/key.d 

OBJS += \
./targetConfigs/KEY/key.o 

OBJS__QUOTED += \
"targetConfigs\KEY\key.o" 

C_DEPS__QUOTED += \
"targetConfigs\KEY\key.d" 

C_SRCS__QUOTED += \
"../targetConfigs/KEY/key.c" 



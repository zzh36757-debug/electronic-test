# CCS 项目在 VS Code 中消除红线 — 配置模板

## 新建项目只需一步

复制这个文件到项目的 `.vscode/c_cpp_properties.json`，改两处：
1. `defines` 里的芯片型号（如 `__MSPM0G3507__`）
2. SDK 路径的版本号（如 `mspm0_sdk_2_10_00_04`）

```json
{
    "configurations": [
        {
            "name": "MSPM0_Config",
            "compileCommands": "${workspaceFolder}/Debug/.clangd/compile_commands.json",
            "includePath": [
                "${workspaceFolder}",
                "${workspaceFolder}/Debug/syscfg",
                "D:/TI/CCS/mspm0_sdk_2_10_00_04/source",
                "D:/TI/CCS/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include",
                "D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/include",
                "D:/TI/CCS/mspm0_sdk_2_10_00_04/kernel/freertos/Source/portable/TI_ARM_CLANG/ARM_CM0",
                "D:/TI/CCS/mspm0_sdk_2_10_00_04/source/ti/posix/ticlang"
            ],
            "defines": [
                "__MSPM0G3507__"
            ],
            "compilerPath": "D:/TI/CCS/ccs/tools/compiler/ti-cgt-armllvm_4.0.3.LTS/bin/tiarmclang.exe",
            "cStandard": "c11",
            "intelliSenseMode": "windows-clang-arm"
        }
    ],
    "version": 4
}
```

## 关键说明

- **compileCommands** — 最重要！指向 CCS 编译后自动生成的编译数据库，VS Code 从这里拿 include 路径
- **includePath** — fallback，compileCommands 优先
- **Debug/syscfg** — 必须有，`ti_msp_dl_config.h` 在这里
- **FreeRTOS 路径** — 要有 kernel 和 portable 两个目录
- **新模块子目录** — 在 CCS Properties 里加上后编译一次，compile_commands.json 自动更新

## 如果还有红线

检查三样：
1. CCS 里编译过一次没有（generate compile_commands.json）
2. `.clangd` 文件里有没有 `Suppress: '*'`（有就删掉）
3. SDK 版本号对不对

## 流程

CCS 建项目 → 编译一次 → 复制本文件 → 改 defines → Reload Window → 没红线了
